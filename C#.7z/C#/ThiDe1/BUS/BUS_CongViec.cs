﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAO;

namespace BUS
{
    public class BUS_CongViec
    {   
        public static DataTable Select()
        {
            return DAO_CongViec.Select();
        }
        public static void Insert(string maCV, string TenCV, long Luong)
        {
            DAO_CongViec.Insert(maCV, TenCV, Luong);
        }
        public static void Update(string maCV, string TenCV, long Luong)
        {
            DAO_CongViec.Update(maCV, TenCV, Luong);
        }
        public static int DemMa(string maCV)
        {
            return DAO_CongViec.DemMa(maCV);
        }
    }
}
