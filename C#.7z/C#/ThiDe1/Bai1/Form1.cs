﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BUS;
using cExcel = Microsoft.Office.Interop.Excel;

namespace Bai1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dgvCongViec.DataSource = BUS_CongViec.Select();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            if(txtMaCV.Text== string.Empty|| txtTenCV.Text == string.Empty|| txtLuong.Text == string.Empty)
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!");
            }
            else
            {
                try
                {
                    if (BUS_CongViec.DemMa(txtMaCV.Text)>0)
                    {
                        MessageBox.Show("Mã đã tồn tại, vui lòng nhập lại!");
                    }
                    else {
                        BUS_CongViec.Insert(txtMaCV.Text, txtTenCV.Text, long.Parse(txtLuong.Text));
                        dgvCongViec.DataSource = BUS_CongViec.Select();
                    }
                    
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            
            
        }

        private void dgvCongViec_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.RowIndex >= 0)
            {
                txtMaCV.Text = dgvCongViec.Rows[e.RowIndex].Cells[0].Value.ToString();
                txtTenCV.Text = dgvCongViec.Rows[e.RowIndex].Cells[1].Value.ToString();
                txtLuong.Text = dgvCongViec.Rows[e.RowIndex].Cells[2].Value.ToString();
                btnSua.Enabled = true;
                btnXoa.Enabled = true;
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            try
            {
                txtMaCV.Enabled = false;
                BUS_CongViec.Update(txtMaCV.Text, txtTenCV.Text, long.Parse(txtLuong.Text));
                dgvCongViec.DataSource = BUS_CongViec.Select();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        
    }
}
