﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
    public class DBConnection
    {
        public static SqlConnection Connection()
        {
            SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-OCUUTDBF\SQLEXPRESS;Initial Catalog=QLCongViec;User ID=sa;Password=123");
            return conn;
        }
    }
}
