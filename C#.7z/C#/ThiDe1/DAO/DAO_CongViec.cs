﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DAO
{
    public class DAO_CongViec
    {
        public static DataTable Select()
        {
            SqlConnection conn = DBConnection.Connection();
            conn.Open();
            SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM CONGVIEC", conn);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            conn.Close();
            return dataTable;
        }
        public static void Insert(string maCV, string TenCV, long Luong)
        {
            SqlConnection conn = DBConnection.Connection();
            conn.Open();
            string sql = string.Format("INSERT INTO CONGVIEC VALUES (N'{0}',N'{1}',{2})", maCV, TenCV, Luong);
            SqlCommand cmd = new SqlCommand(sql,conn);
            cmd.ExecuteNonQuery();
            conn.Close();
        }
        public static void Update(string maCV, string TenCV, long Luong)
        {
            SqlConnection conn = DBConnection.Connection();
            conn.Open();
            string sql = string.Format("UPDATE  CONGVIEC SET TENCV = N'{0}', LUONGTHANG = {1} WHERE MACV = N'{2}'", TenCV, Luong, maCV  );
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.ExecuteNonQuery();
            conn.Close();
        }
        public static int DemMa(string maCV)
        {
            SqlConnection con = DBConnection.Connection();
            con.Open();
            string sql = string.Format("select count(*) from CONGVIEC where MaCV = N'{0}'", maCV);
            SqlCommand comm = new SqlCommand(sql, con);
            var count = comm.ExecuteScalar();
            con.Close();
            return (int)count;
        }
    }
}
