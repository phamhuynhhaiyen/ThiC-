﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
    public class VatLieuDAO
    {
        public static DataTable Select()
        {
            SqlConnection con = DBConnection.KetNoi();
            con.Open();
            SqlDataAdapter adapter = new SqlDataAdapter("select * from VatLieu", con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            con.Close();
            return dt;
        }
        public static void XuLi(string s)
        {
            SqlConnection con = DBConnection.KetNoi();
            con.Open();
            SqlCommand comm = new SqlCommand(s,con);
            comm.ExecuteNonQuery();
            con.Close();
        }
        public static int DemMa(string maVL)
        {
            SqlConnection con = DBConnection.KetNoi();
            con.Open();
            string sql = string.Format("select count(*) from VatLieu where MaVL = N'{0}'", maVL);
            SqlCommand comm = new SqlCommand(sql, con);
            var count = comm.ExecuteScalar();
            con.Close();
            return (int) count;
        }
    }
}
