﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
    public class DBConnection
    {
        public static SqlConnection KetNoi()
        {
            SqlConnection sql = new SqlConnection(@"Data Source=LAPTOP-OCUUTDBF\SQLEXPRESS;Initial Catalog=QLVatLieu;Integrated Security=True");
            return sql;
        }
    }
}
