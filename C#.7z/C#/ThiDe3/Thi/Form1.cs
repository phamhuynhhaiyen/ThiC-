﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BUS;

namespace Thi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string fileimage;
        private void btnAnh_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog op = new OpenFileDialog();
                if (DialogResult.OK == op.ShowDialog())
                {
                    op.Filter = "insert image(*)|*";
                    string source = op.FileName;
                    fileimage = Path.GetFileName(op.FileName);
                    string desc = Path.Combine(@"Images\", fileimage);
                    File.Copy(source, desc, true);
                    pictureBox1.Image = Image.FromFile(desc);
                }
            }
            catch (Exception)
            {

                throw;
            }
                     
            
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            if(txtMaVL.Text == string.Empty || txtTen.Text == string.Empty || txtDVT.Text == string.Empty || txtGiaNhap.Text == string.Empty || txtGiaBan.Text == string.Empty || txtSL.Text == string.Empty || txtGhiChu.Text == string.Empty|| pictureBox1.Image == null)
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!");
            }
            else
            {
                try
                {
                    if (VatLieuBUS.DemMa(txtMaVL.Text) > 0)
                    {
                        MessageBox.Show("Đã tồn tại mã này, vui lòng nhập lại!");
                    }
                    else
                    {
                        VatLieuBUS.Them(txtMaVL.Text, txtTen.Text, txtDVT.Text, long.Parse(txtGiaNhap.Text), long.Parse(txtGiaBan.Text), int.Parse(txtSL.Text), fileimage, txtGhiChu.Text);
                        dgvVatLieu.DataSource = VatLieuBUS.Select();
                    }
                    
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }
            }
            
            

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dgvVatLieu.DataSource = VatLieuBUS.Select();
        }

        private void dgvVatLieu_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    txtMaVL.Text = dgvVatLieu.Rows[e.RowIndex].Cells[0].Value.ToString();
                    txtTen.Text = dgvVatLieu.Rows[e.RowIndex].Cells[1].Value.ToString();
                    txtDVT.Text = dgvVatLieu.Rows[e.RowIndex].Cells[2].Value.ToString();
                    txtGiaNhap.Text = dgvVatLieu.Rows[e.RowIndex].Cells[3].Value.ToString();
                    txtGiaBan.Text = dgvVatLieu.Rows[e.RowIndex].Cells[4].Value.ToString();
                    txtSL.Text = dgvVatLieu.Rows[e.RowIndex].Cells[5].Value.ToString();
                    pictureBox1.Image = Image.FromFile(@"Images\"+dgvVatLieu.Rows[e.RowIndex].Cells[6].Value.ToString());

                    txtGhiChu.Text = dgvVatLieu.Rows[e.RowIndex].Cells[7].Value.ToString();
                }
            }
            catch { }
            
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            try
            {
                if(MessageBox.Show("Bạn có chắc chắn muốn xóa?", "Thông báo", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    
                    VatLieuBUS.Xoa(txtMaVL.Text);
                }
                
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            dgvVatLieu.DataSource = VatLieuBUS.Select();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            try
            {
               
                VatLieuBUS.Sua(txtMaVL.Text, txtTen.Text, txtDVT.Text, long.Parse(txtGiaNhap.Text), long.Parse(txtGiaBan.Text), int.Parse(txtSL.Text), fileimage, txtGhiChu.Text);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            dgvVatLieu.DataSource = VatLieuBUS.Select();
        }

        private void btnBoQua_Click(object sender, EventArgs e)
        {
            txtMaVL.Text= txtTen.Text= txtDVT.Text=txtGiaNhap.Text= txtGiaBan.Text= txtSL.Text=txtGhiChu.Text = "";
            pictureBox1.Image = null;
        }
    }
}
