﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAO;

namespace BUS
{
    public class VatLieuBUS
    {
        public static DataTable Select()
        {
            return VatLieuDAO.Select();
        }
        public static void Them(string mavl, string ten,string dvt, long gianhap, long giaban, int SL, string fileimage, string ghichu)
        {
            string s = string.Format("insert into VatLieu values(N'{0}', N'{1}', N'{2}', {3}, {4}, {5}, N'{6}', N'{7}')", mavl, ten,dvt, gianhap, giaban,  SL,  fileimage,  ghichu);
            VatLieuDAO.XuLi(s);
        }
        public static void Xoa(string maVL)
        {
            string s = string.Format("delete from VatLieu where MaVL = '{0}'", maVL);
            VatLieuDAO.XuLi(s);
        }
        public static void Sua(string mavl, string ten, string dvt, long gianhap, long giaban, int SL, string fileimage, string ghichu)
        {
            string s = string.Format("update VatLieu set TenVL=N'{0}', DonViTinh = N'{1}', GiaNhap = {2}, GiaBan = 3}, Soluong = {4}, FileAnh = N'{5}, GhiChu = N'{6} where MaVL = N'{7}'", ten, dvt, gianhap, giaban, SL, fileimage, ghichu, mavl);
            VatLieuDAO.XuLi(s);
        }
        public static int DemMa(string maVL)
        {
            return VatLieuDAO.DemMa(maVL);
        }
        
    }
}
