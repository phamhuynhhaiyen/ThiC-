﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAO;

namespace BUS
{
    public class XuLi
    {
        public static DataTable SelectAll()
        {
            return KetNoi.Select("select * from HangHoa");
        }
        //public static DataTable SelectMaHang(string mahang)
        //{
        //    string sql = string.Format("select * from HangHoa where MaHang = N'{0}'", mahang);
        //    return KetNoi.Select(sql);
        //}
        //public static DataTable SelectTenHang(string tenhang)
        //{
        //    string sql = string.Format("select * from HangHoa where TenHang = N'{0}'", tenhang);
        //    return KetNoi.Select(sql);
        //}
        //public static DataTable SelectGia(long giaTu, long giaDen)
        //{
        //    string sql = string.Format("select * from HangHoa where GiaBan > {0} and GiaBan < {1}", giaTu, giaDen);
        //    return KetNoi.Select(sql);
        //}
        public static DataTable SelectAllChatLieu()
        {
            string sql = string.Format("select TenChatLieu from HangHoa group by TenChatLieu");
            return KetNoi.Select(sql);
        }
        //public static DataTable SelectChatLieu(string chatlieu)
        //{
        //    string sql = string.Format("select * from HangHoa where TenChatLieu = N'{0}'", chatlieu);
        //    return KetNoi.Select(sql);
        //}
        public static DataTable TimKiem(string maH, string tenH, string chatlieu)
        {
            string sql = string.Format("select * from HangHoa where MaHang like '%{0}%' and TenHang like '%{1}%' and TenChatLieu like N'%{2}%'", maH, tenH, chatlieu);
            return KetNoi.Select(sql);
        }
        public static DataTable TimKiemChuaGia(string maH, string tenH, string chatlieu, long giatu, long giaden)
        {
            string sql = string.Format("select * from HangHoa where MaHang like '%{0}%' and TenHang like '%{1}%' and TenChatLieu like N'%{3}%' and DonGiaBan >= {3} and DonGiaBan <= {4}", maH, tenH, chatlieu, giatu, giaden);
            return KetNoi.Select(sql);
        }
    }
}
