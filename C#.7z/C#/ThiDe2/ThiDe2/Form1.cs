﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BUS;
using cExcel = Microsoft.Office.Interop.Excel;

namespace ThiDe2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                dgvHang.DataSource = XuLi.SelectAll();
                
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            
        }

        private void btnTim_Click(object sender, EventArgs e)
        {
            try
            {
                if(txtGiaTu.Text == string.Empty||txtGiaD.Text == string.Empty)
                {
                    dgvHang.DataSource = XuLi.TimKiem(txtMaH.Text, txtTenH.Text, cbbChatLieu.Text);
                }
                else
                {
                    dgvHang.DataSource = XuLi.TimKiemChuaGia(txtMaH.Text, txtTenH.Text, cbbChatLieu.Text, long.Parse(txtGiaTu.Text), long.Parse(txtGiaD.Text));
                }
                
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void btnIn_Click(object sender, EventArgs e)
        {
            try
            {
                

                cExcel.Application app = new cExcel.Application();
                cExcel.Workbook workbook = app.Workbooks.Add(Type.Missing);
                cExcel.Worksheet worksheet = workbook.ActiveSheet;
                app.Visible = true;
                worksheet.Cells.ColumnWidth = 15;
                for (int i = 1; i <= dgvHang.Columns.Count; i++)
                {
                    worksheet.Cells[1, i] = dgvHang.Columns[i - 1].HeaderText.ToString();
                    
                    worksheet.Cells[1, i].Interior.Color = ColorTranslator.ToOle(Color.Yellow);
                    //worksheet.Cells[1, i]
                }
                for (int i = 0; i < dgvHang.Rows.Count; i++)
                {
                    for (int j = 0; j < dgvHang.Columns.Count; j++)
                    {
                        worksheet.Cells[i + 2, j+1] = dgvHang.Rows[i].Cells[j].Value;
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            
            

        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            
            if(MessageBox.Show("Bạn có chắc chắn muốn thoát!", "Thông báo", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Application.Exit();
            }
            
        }

        private void cbbChatLieu_Click(object sender, EventArgs e)
        {
            cbbChatLieu.DataSource = XuLi.SelectAllChatLieu();
            cbbChatLieu.ValueMember = cbbChatLieu.DisplayMember = "TenChatLieu";
        }
    }
}
